package tetz42.test;

public class Hello {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(new Hello().say(args));
	}

	public String say(String[] args) {
		System.out.println("Hello#say() is called.");
		StringBuilder sb = new StringBuilder();
		sb.append("Hello, ");
		for(String arg : args)
			sb.append(arg).append("!");
		return sb.toString();
	}
}
