package tetz42.test;

public class RecordMock {

}
