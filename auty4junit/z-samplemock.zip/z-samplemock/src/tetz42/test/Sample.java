package tetz42.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;

public class Sample {

	public static void premain(String agentArgs, Instrumentation instrumentation) {

//		@SuppressWarnings("rawtypes")
//		Class[] classes = instrumentation.getAllLoadedClasses();
//		for (@SuppressWarnings("rawtypes")
//		Class cls : classes) {
//			System.out.println(cls);
//		}
		
		final ClassPool pool = ClassPool.getDefault();
		
		instrumentation.addTransformer(new ClassFileTransformer() {

			@Override
			public byte[] transform(ClassLoader loader, String className,
					Class<?> clazz, ProtectionDomain protectionDomain,
					byte[] clsBuf) throws IllegalClassFormatException {
				
				if(className.endsWith("Hello")){
					ByteArrayInputStream clsStream = new ByteArrayInputStream(clsBuf);
					try {
						CtClass cc = pool.makeClass(clsStream);
						cc.instrument(new ExprEditor(){

							@Override
							public void edit(MethodCall m)
									throws CannotCompileException {
								if(m.getMethodName().equals("say")){
									StringBuilder sb = new StringBuilder();
									sb.append("System.out.println(\"begin\");");
									sb.append("java.io.File file = new java.io.File(\"./sample.txt\");");
									sb.append("if(file.exists()) {");
									sb.append("$_ = new java.io.BufferedReader(new java.io.FileReader(file)).readLine();");
									sb.append("} else {");
									sb.append("$_ = $proceed($$);");
									sb.append("java.io.FileWriter writer = new java.io.FileWriter(file);");
									sb.append("writer.write($_);");
									sb.append("writer.flush();");
									sb.append("writer.close();");
									sb.append("}");
									sb.append("System.out.println(\"end\");");
									m.replace(sb.toString());
								}
							}
						});
						
						return cc.toBytecode();
						
					} catch (IOException e) {
						throw new RuntimeException(e);
					} catch (CannotCompileException e) {
						e.printStackTrace();
						throw new RuntimeException(e);
					}
				}
				
				return null;
			}
		});
	}

}
